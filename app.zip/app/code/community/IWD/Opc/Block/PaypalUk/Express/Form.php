<?php
class IWD_Opc_Block_PaypalUk_Express_Form extends IWD_Opc_Block_Paypal_Express_Form
{
    protected $_methodCode = Mage_Paypal_Model_Config::METHOD_WPP_PE_EXPRESS;
}
